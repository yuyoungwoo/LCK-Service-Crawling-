package com.itbank.model;



public class LCKTeamInfoDTO {

	private String teamName;
	private String teamimg;
	private String top;
	private String jungle;
	private String mid;
	private String adCarry;
	private String supporter;
	private String coach;
	private String headCoach;
	private String topImageURL;
	private String jungleImageURL;
	private String midImageURL;
	private String adCarryImageURL;
	private String supporterImageURL;
	
	
	public String getTeamimg() {
		return teamimg;
	}
	public void setTeamimg(String teamimg) {
		this.teamimg = teamimg;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getTop() {
		return top;
	}
	public void setTop(String top) {
		this.top = top;
	}
	public String getJungle() {
		return jungle;
	}
	public void setJungle(String jungle) {
		this.jungle = jungle;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getAdCarry() {
		return adCarry;
	}
	public void setAdCarry(String adCarry) {
		this.adCarry = adCarry;
	}
	public String getSupporter() {
		return supporter;
	}
	public void setSupporter(String supporter) {
		this.supporter = supporter;
	}
	public String getCoach() {
		return coach;
	}
	public void setCoach(String coach) {
		this.coach = coach;
	}
	public String getHeadCoach() {
		return headCoach;
	}
	public void setHeadCoach(String headCoach) {
		this.headCoach = headCoach;
	}
	public String getTopImageURL() {
		return topImageURL;
	}
	public void setTopImageURL(String topImageURL) {
		this.topImageURL = topImageURL;
	}
	public String getJungleImageURL() {
		return jungleImageURL;
	}
	public void setJungleImageURL(String jungleImageURL) {
		this.jungleImageURL = jungleImageURL;
	}
	
	public String getMidImageURL() {
		return midImageURL;
	}
	public void setMidImageURL(String midImageURL) {
		this.midImageURL = midImageURL;
	}
	public String getAdCarryImageURL() {
		return adCarryImageURL;
	}
	public void setAdCarryImageURL(String adCarryImageURL) {
		this.adCarryImageURL = adCarryImageURL;
	}
	public String getSupporterImageURL() {
		return supporterImageURL;
	}
	public void setSupporterImageURL(String supporterImageURL) {
		this.supporterImageURL = supporterImageURL;
	}
	

	
	
	
	
	
}
